from __future__ import print_function

import numpy as np
import sys

import sys
sys.path.insert(0, '/usr/lib/python2.7/site-packages')

import argparse
from char_word_seq2seq_utils import *

from tensorflow.keras.preprocessing.sequence import pad_sequences

ap = argparse.ArgumentParser()
ap.add_argument('-max_len', type=int, default=200)
ap.add_argument('-max_len_char', type=int, default=15)

ap.add_argument('-vocab_size', type=int, default=30000)
ap.add_argument('-vocab_size_char', type=int, default=50)
ap.add_argument('-batch_size', type=int, default=1000)

ap.add_argument('-layer_num', type=int, default=3)

ap.add_argument('-hidden_dim', type=int, default=500)

ap.add_argument('-nb_epoch', type=int, default=15)

#ap.add_argument('-mode', default='train')
ap.add_argument('-mode', default='test')

args = vars(ap.parse_args())

MAX_LEN = args['max_len']
MAX_LEN_CHAR = args['max_len_char']
VOCAB_SIZE = args['vocab_size']
VOCAB_SIZE_CHAR = args['vocab_size_char']
BATCH_SIZE = args['batch_size']
LAYER_NUM = args['layer_num']
HIDDEN_DIM = args['hidden_dim']
NB_EPOCH = args['nb_epoch']
MODE = args['mode']

if __name__ == '__main__':
    # Loading input sequences, output sequences and the necessary mapping dictionaries
    print('[INFO] Loading data...')
    #train_names.txt
    X_word, X_word_vocab_len, X_word_word_to_ix, X_word_ix_to_word, y, y_vocab_len, y_word_to_ix, y_ix_to_word = load_word_data('TrainData/train_names.txt', 'TrainData/train_states.txt', MAX_LEN, VOCAB_SIZE)
    X_word_max_len = max([len(sentence) for sentence in X_word])
    X_char, X_char_vocab_len, X_char_word_to_ix, X_char_ix_to_word = load_char_data('TrainData/train_names.txt', 'TrainData/train_states.txt', X_word_max_len,MAX_LEN_CHAR, VOCAB_SIZE_CHAR)

    # Finding the length of the longest sequence
    
    X_char_max_len = MAX_LEN_CHAR
    y_max_len = max([len(sentence) for sentence in y])

    # Padding zeros to make all sequences have a same length with the longest one
    print('[INFO] Zero padding...')
    X_word = pad_sequences(X_word, maxlen=X_word_max_len, dtype='int32')
    y = pad_sequences(y, maxlen=y_max_len, dtype='int32')

    # Creating the network model
    print('[INFO] Compiling model...')
    model = create_model(X_word_vocab_len, X_word_max_len,X_char_vocab_len, X_char_max_len, y_vocab_len, y_max_len, HIDDEN_DIM, LAYER_NUM)

    print('[INFO] Compiled model...')
    # Finding trained weights of previous epoch if any
    saved_weights = find_checkpoint_file('.')

    # Training only if we chose training mode
    if MODE == 'train':
        k_start = 1

        # If any trained weight was found, then load them into the model
        if len(saved_weights) != 0:
            print('[INFO] Saved weights found, loading...')
            epoch = saved_weights[saved_weights.rfind('_')+1:saved_weights.rfind('.')]
            model.load_weights(saved_weights)
            k_start = int(epoch) + 1

            i_end = 0
        for k in range(k_start, NB_EPOCH+1):
            # Shuffling the training data every epoch to avoid local minima
            indices = np.arange(len(X_word))
            np.random.shuffle(indices)
            X_word = X_word[indices]
            X_char = [X_char[i] for i in indices]
            y = y[indices]

            # Training BATCH_SIZE sequences at a time
            for i in range(0, len(X_word), BATCH_SIZE):
                if i + BATCH_SIZE >= len(X_word):
                    i_end = len(X_word)
                else:
                    i_end = i + BATCH_SIZE
                y_sequences = process_data(y[i:i_end], y_max_len, y_word_to_ix)
                print('[INFO] Training model: epoch {}th {}/{} samples'.format(k, i, len(X_word)))
                X_modif=[X_char[k] for k in range(i,i_end)]
                model.fit([X_word[i:i_end],np.asarray(X_modif)], y_sequences, batch_size=BATCH_SIZE, nb_epoch=1, verbose=2)
            model.save_weights('checkpoint_epoch_{}.hdf5'.format(k))
    
    # Performing test if we chose test mode
    else:
        # Only performing test if there is any saved weights
        if len(saved_weights) == 0:
            print("The network hasn't been trained! Program will exit...")
            sys.exit()
        else:
            #X_test_without_pad = load_test_data('Testcases/test_names.txt', X_word_to_ix, MAX_LEN)
            X_test_without_pad_word = load_test_data_word('TestData/test_names.txt', X_word_word_to_ix,X_word_max_len )
            X_test_word = pad_sequences(X_test_without_pad_word, maxlen=X_word_max_len, dtype='int32')
            X_test_char = load_test_data_char('TestData/test_names.txt', X_char_word_to_ix, X_word_max_len,MAX_LEN_CHAR)
            model.load_weights(saved_weights)

            X_char=[X_test_char[k] for k in range(len(X_test_char))]
            predictions = np.argmax(model.predict([X_test_word,np.asarray(X_char)]), axis=2)
            sequences = []
            for i in range(len(predictions)):
                sequence = ' '.join([y_ix_to_word[predictions[i][index]] for index in range(X_word_max_len-len(X_test_without_pad_word[i]),len(predictions[i])) if index >= 0])
                sequences.append(sequence)
            np.savetxt('test_result', sequences, fmt='%s')

