#!/bin/sh

#See example below
#python3 resultcompare.py $CODEPATH/wordSoftmax/test_result $DATAPATH/TestData/test_states.txt
