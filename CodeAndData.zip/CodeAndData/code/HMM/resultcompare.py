import sys
class ResultCompare:
    def compare(self, filename1, filename2):
        file1 = open(filename1, 'r')      
        file2 = open(filename2, 'r')     
        content1=file1.readlines()
        content2=file2.readlines()
        content1=[x.lower().strip() for x in content1]
        print(content1)
        print("+++++++++++++++++")
        content2=[x.lower().strip() for x in content2]
        print(content2)
        print("+++++++++++++++++")
      
        print("#content1 = ", len(content1))
        print("#content2 = ", len(content2))
        correct_count = 0
        incorrect_count = 0
        for k in range(0,len(content2)):
            i = 0
            
            if content1[k] == content2[k]:
                    correct_count += 1
                    
            else:
                    incorrect_count += 1
        print("Correct count = ", correct_count)
        print("Total count = ", incorrect_count+correct_count)
        print(float(correct_count)/(correct_count+incorrect_count))


if __name__ == '__main__':
    file1 = sys.argv[1]  #golden (TestData/test_states.txt)
    file2 = sys.argv[2]  #test result 
    model = ResultCompare()
    model.compare(file1, file2)
